# Sweep Half Swept
![](/gallery/sweep-half-swept.jpg)

Half of a Sweep2 with a reversible micro-controller footprint.
