# Sweep Compact LOW
![](/gallery/sweep-compact-low.jpg)

This is the only Sweep version that supports the "Choc Mini" switch.
