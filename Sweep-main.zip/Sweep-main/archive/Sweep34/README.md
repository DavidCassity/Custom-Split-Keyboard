# Sweep 34
![](/gallery/sweep-34.jpg)

This is the first ever version of the Sweep! It was created before there was a choc spaced Ferris.  
The Half Swept version is very similar but offers more features.

## Features

| Device | Bluetooth Support<sup>[1]</sup> | On/Off Switch | Reversible PCB | Choc V1 | Choc V2 | Choc Mini | MX & Alps | Choc Spacing<sup>[2]</sup> | Tenting<sup>[3]</sup> |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| Sweep 34     | ✔ |   | ✔ | ✔ |   |   |   | ✔ |   |
