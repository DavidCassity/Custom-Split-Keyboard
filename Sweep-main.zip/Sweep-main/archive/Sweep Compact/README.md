# Sweep Compact
![](/gallery/sweep-compact.jpg)

This is an older revision.  
The Half Swept version is very similar but offers more features.

⚠ *Left* half of the Sweep the promicro's USB port must face *towards* the PCB, and on the *right* half the USB port must face *away* from the PCB (so that the promicro's components are visible)

## Features

| Device | Bluetooth Support<sup>[1]</sup> | On/Off Switch | Reversible PCB | Choc V1 | Choc V2 | Choc Mini | MX & Alps | Choc Spacing<sup>[2]</sup> | Tenting<sup>[3]</sup> |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| Sweep Compact     | ✔ |   | ✔ | ✔ |   |   |   | ✔ |   |
