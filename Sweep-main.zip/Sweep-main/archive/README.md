# Archive (of Legacy Versions)

You are viewing the archive section of the Sweep repository.  
Here you will find all of the older revisions of the Sweep.

If a version is here, it means that there is another version that is "the same but better" outside of this folder.
