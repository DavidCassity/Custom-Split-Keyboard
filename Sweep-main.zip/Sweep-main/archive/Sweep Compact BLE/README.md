# Sweep Compact BLE
![](/gallery/sweep-compact-ble.jpg)

This is an older revision.  
The Half Swept version is very similar but offers more features.

The main difference in this design is the missing TRRS jack footprint.

## Features

| Device | Bluetooth Support<sup>[1]</sup> | On/Off Switch | Reversible PCB | Choc V1 | Choc V2 | Choc Mini | MX & Alps | Choc Spacing<sup>[2]</sup> | Tenting<sup>[3]</sup> |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| Sweep Compact BLE | ✔ |   | ✔ | ✔ |   |   |   | ✔ |   |
