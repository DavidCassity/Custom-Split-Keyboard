tentative half sweep high for free allpcb usage.
